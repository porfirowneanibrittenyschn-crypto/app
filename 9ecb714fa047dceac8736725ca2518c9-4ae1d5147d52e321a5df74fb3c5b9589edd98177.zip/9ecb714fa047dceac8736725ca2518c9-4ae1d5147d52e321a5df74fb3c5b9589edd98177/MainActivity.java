package com.rgzn.wzh;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.rgzn.wzh.records.RecordActivity;
import com.rgzn.wzh.steps.StepCounterActivity;
import com.rgzn.wzh.tips.HealthTipsActivity;
import com.rgzn.wzh.profile.ProfileActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 绑定卡片点击跳转事件
        findViewById(R.id.card_records).setOnClickListener(v -> startActivity(new Intent(this, RecordActivity.class)));
        findViewById(R.id.card_steps).setOnClickListener(v -> startActivity(new Intent(this, StepCounterActivity.class)));
        findViewById(R.id.card_tips).setOnClickListener(v -> startActivity(new Intent(this, HealthTipsActivity.class)));
        findViewById(R.id.card_profile).setOnClickListener(v -> startActivity(new Intent(this, ProfileActivity.class)));

        // 主界面退出按钮
        findViewById(R.id.btn_exit).setOnClickListener(v -> finish());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, R.string.menu_about);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 1) {
            showAboutDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showAboutDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.about_title)
                .setMessage(R.string.about_content)
                .setPositiveButton(android.R.string.ok, null)
                .show();
    }
}